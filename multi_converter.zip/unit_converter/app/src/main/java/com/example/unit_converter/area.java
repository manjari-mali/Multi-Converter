package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class area extends AppCompatActivity {
    ImageView back;
    private EditText inputValue;
    private Spinner fromUnitSpinner, toUnitSpinner;
    private TextView resultText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_area);

        // Initialize UI components
        back = findViewById(R.id.back);
        inputValue = findViewById(R.id.input_value);
        fromUnitSpinner = findViewById(R.id.from_unit_spinner);
        toUnitSpinner = findViewById(R.id.to_unit_spinner);
        resultText = findViewById(R.id.result_text);
        convertButton = findViewById(R.id.convert_button);

        // Set up back button
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), home.class);
                startActivity(i);
                finish();
            }
        });

        // Set up the spinners with unit options
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.area_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value to convert", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double value = Double.parseDouble(input);
            String fromUnit = fromUnitSpinner.getSelectedItem().toString();
            String toUnit = toUnitSpinner.getSelectedItem().toString();

            double result = convertUnits(value, fromUnit, toUnit);
            resultText.setText(String.format("%.2f %s", result, toUnit));
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input. Please enter a valid number.", Toast.LENGTH_SHORT).show();
        }
    }

    private double convertUnits(double value, String fromUnit, String toUnit) {
        // Convert the input value to square meters as a base unit
        double valueInSquareMeters = value;
        switch (fromUnit) {
            case "Square Meter":
                valueInSquareMeters = value;
                break;
            case "Square Kilometer":
                valueInSquareMeters = value * 1_000_000; // 1 km² = 1,000,000 m²
                break;
            case "Acre":
                valueInSquareMeters = value * 4046.86; // 1 acre = 4046.86 m²
                break;
            case "Square Foot":
                valueInSquareMeters = value * 0.092903; // 1 ft² = 0.092903 m²
                break;
        }

        // Convert from square meters to the target unit
        switch (toUnit) {
            case "Square Meter":
                return valueInSquareMeters;
            case "Square Kilometer":
                return valueInSquareMeters / 1_000_000;
            case "Acre":
                return valueInSquareMeters / 4046.86;
            case "Square Foot":
                return valueInSquareMeters / 0.092903;
            default:
                return value;
        }
    }
}
