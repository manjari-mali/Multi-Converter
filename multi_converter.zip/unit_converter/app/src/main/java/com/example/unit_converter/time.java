package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class time extends AppCompatActivity {
    ImageView back;
    private EditText inputValue;
    private Spinner fromUnitSpinner, toUnitSpinner;
    private TextView resultText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);

        // Initialize UI components
        inputValue = findViewById(R.id.input_value);
        fromUnitSpinner = findViewById(R.id.from_unit_spinner);
        toUnitSpinner = findViewById(R.id.to_unit_spinner);
        resultText = findViewById(R.id.result_text);
        convertButton = findViewById(R.id.convert_button);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), home.class);
                startActivity(i);
                finish();
            }
        });

        // Set up the spinners with time units
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.time_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value to convert", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(input);
        String fromUnit = fromUnitSpinner.getSelectedItem().toString();
        String toUnit = toUnitSpinner.getSelectedItem().toString();

        double result = convertUnits(value, fromUnit, toUnit);
        resultText.setText(String.format("%.2f %s", result, toUnit));
    }

    private double convertUnits(double value, String fromUnit, String toUnit) {
        // Convert the input value to seconds as the base unit
        double valueInSeconds = value;
        switch (fromUnit) {
            case "Minute (min)":
                valueInSeconds = value * 60;
                break;
            case "Hour (h)":
                valueInSeconds = value * 3600;
                break;
            case "Day (d)":
                valueInSeconds = value * 86400;
                break;
            case "Week":
                valueInSeconds = value * 604800;
                break;
            case "Month":
                valueInSeconds = value * 2592000; // Approximation: 30 days = 2592000 seconds
                break;
            case "Year":
                valueInSeconds = value * 31536000; // Approximation: 365 days = 31536000 seconds
                break;
            case "Second (s)":
                valueInSeconds = value;
                break;
        }

        // Convert from seconds to the target unit
        switch (toUnit) {
            case "Minute (min)":
                return valueInSeconds / 60;
            case "Hour (h)":
                return valueInSeconds / 3600;
            case "Day (d)":
                return valueInSeconds / 86400;
            case "Week":
                return valueInSeconds / 604800;
            case "Month":
                return valueInSeconds / 2592000;
            case "Year":
                return valueInSeconds / 31536000;
            case "Second (s)":
                return valueInSeconds;
            default:
                return value;
        }
    }
}
