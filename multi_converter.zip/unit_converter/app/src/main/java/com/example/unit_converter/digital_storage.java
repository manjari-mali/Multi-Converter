package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class digital_storage extends AppCompatActivity {
    ImageView back;
    private EditText inputValue;
    private Spinner fromUnitSpinner, toUnitSpinner;
    private TextView resultText;
    private Button convertButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_digital_storage);
        back=findViewById(R.id.back);
        inputValue = findViewById(R.id.input_value);
        fromUnitSpinner = findViewById(R.id.from_unit_spinner);
        toUnitSpinner = findViewById(R.id.to_unit_spinner);
        resultText = findViewById(R.id.result_text);
        convertButton = findViewById(R.id.convert_button);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(getApplicationContext(), home.class);
                startActivity(i);
                finish();
            }
        });
        // Set up the spinners with digital storage units
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.digital_storage_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }
    private void performConversion() {
        String input = inputValue.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value to convert", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(input);
        String fromUnit = fromUnitSpinner.getSelectedItem().toString();
        String toUnit = toUnitSpinner.getSelectedItem().toString();

        double result = convertUnits(value, fromUnit, toUnit);
        resultText.setText(String.format("%.2f %s", result, toUnit));
    }
    private double convertUnits(double value, String fromUnit, String toUnit) {
        // Convert the input value to Bytes as the base unit
        double valueInBytes = value;
        switch (fromUnit) {
            case "Kilobyte (KB)":
                valueInBytes = value * 1024;
                break;
            case "Megabyte (MB)":
                valueInBytes = value * 1024 * 1024;
                break;
            case "Gigabyte (GB)":
                valueInBytes = value * 1024 * 1024 * 1024;
                break;
            case "Terabyte (TB)":
                valueInBytes = value * 1024 * 1024 * 1024 * 1024;
                break;
            case "Byte (B)":
                valueInBytes = value;
                break;
        }
        // Convert from Bytes to the target unit
        switch (toUnit) {
            case "Kilobyte (KB)":
                return valueInBytes / 1024;
            case "Megabyte (MB)":
                return valueInBytes / (1024 * 1024);
            case "Gigabyte (GB)":
                return valueInBytes / (1024 * 1024 * 1024);
            case "Terabyte (TB)":
                return valueInBytes / (1024 * 1024 * 1024 * 1024);
            case "Byte (B)":
                return valueInBytes;
            default:
                return value;
        }
    }

}