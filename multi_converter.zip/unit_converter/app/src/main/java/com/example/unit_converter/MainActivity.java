package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set a delay of 3 seconds before transitioning to the MainActivity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start the MainActivity
                Intent intent = new Intent(MainActivity.this, home.class);
                startActivity(intent);
                finish(); // Close the SplashActivity so the user can't go back to it
            }
        }, 3000); // 3000 milliseconds = 3 seconds
    }
}