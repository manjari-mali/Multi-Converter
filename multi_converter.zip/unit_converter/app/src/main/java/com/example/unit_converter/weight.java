package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class weight extends AppCompatActivity {
    ImageView back;
    private EditText inputValue;
    private Spinner fromUnitSpinner, toUnitSpinner;
    private TextView resultText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);

        // Initialize UI components
        inputValue = findViewById(R.id.input_value);
        fromUnitSpinner = findViewById(R.id.from_unit_spinner);
        toUnitSpinner = findViewById(R.id.to_unit_spinner);
        resultText = findViewById(R.id.result_text);
        convertButton = findViewById(R.id.convert_button);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), home.class);
                startActivity(i);
                finish();
            }
        });

        // Set up the spinners with weight units
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.weight_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value to convert", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(input);
        String fromUnit = fromUnitSpinner.getSelectedItem().toString();
        String toUnit = toUnitSpinner.getSelectedItem().toString();

        double result = convertUnits(value, fromUnit, toUnit);
        resultText.setText(String.format("%.2f %s", result, toUnit));
    }

    private double convertUnits(double value, String fromUnit, String toUnit) {
        // Convert the input value to grams as the base unit
        double valueInGrams = value;
        switch (fromUnit) {
            case "Kilogram":
                valueInGrams = value * 1000;  // 1 Kg = 1000 grams
                break;
            case "Gram":
                valueInGrams = value;
                break;
            case "Pound":
                valueInGrams = value * 453.592;  // 1 Pound = 453.592 grams
                break;
            case "Milligram":
                valueInGrams = value / 1000;  // 1 mg = 0.001 grams
                break;
        }

        // Convert from grams to the target unit
        switch (toUnit) {
            case "Kilogram":
                return valueInGrams / 1000;
            case "Gram":
                return valueInGrams;
            case "Pound":
                return valueInGrams / 453.592;
            case "Milligram":
                return valueInGrams * 1000;
            default:
                return value;
        }
    }
}
