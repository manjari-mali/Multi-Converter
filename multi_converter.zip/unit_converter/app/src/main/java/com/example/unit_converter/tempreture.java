package com.example.unit_converter;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class tempreture extends AppCompatActivity {
    ImageView back;
    private EditText inputValue;
    private Spinner fromUnitSpinner, toUnitSpinner;
    private TextView resultText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tempreture);

        // Initialize UI components
        inputValue = findViewById(R.id.input_value);
        fromUnitSpinner = findViewById(R.id.from_unit_spinner);
        toUnitSpinner = findViewById(R.id.to_unit_spinner);
        resultText = findViewById(R.id.result_text);
        convertButton = findViewById(R.id.convert_button);
        back = findViewById(R.id.back);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(), home.class);
                startActivity(i);
                finish();
            }
        });

        // Set up the spinners with temperature units
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.tempreture_units, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromUnitSpinner.setAdapter(adapter);
        toUnitSpinner.setAdapter(adapter);

        // Set up the convert button click listener
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();
        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter a value to convert", Toast.LENGTH_SHORT).show();
            return;
        }

        double value = Double.parseDouble(input);
        String fromUnit = fromUnitSpinner.getSelectedItem().toString();
        String toUnit = toUnitSpinner.getSelectedItem().toString();

        double result = convertUnits(value, fromUnit, toUnit);
        resultText.setText(String.format("%.2f %s", result, toUnit));
    }

    private double convertUnits(double value, String fromUnit, String toUnit) {
        // Convert the input value to Celsius as the base unit
        double valueInCelsius = value;
        switch (fromUnit) {
            case "Fahrenheit (°F)":
                valueInCelsius = (value - 32) * 5 / 9;
                break;
            case "Kelvin (K)":
                valueInCelsius = value - 273.15;
                break;
            case "Celsius (°C)":
                valueInCelsius = value;
                break;
        }

        // Convert from Celsius to the target unit
        switch (toUnit) {
            case "Fahrenheit (°F)":
                return (valueInCelsius * 9 / 5) + 32;
            case "Kelvin (K)":
                return valueInCelsius + 273.15;
            case "Celsius (°C)":
                return valueInCelsius;
            default:
                return value;
        }
    }
}
